class Kino():

    def __init__(self, id, dvorana, red, mjestau_redovima):
        self._id = id
        self._dvorana = dvorana
        self._red = red
        self._mjestau_redovima = mjestau_redovima

    @property
    def id(self):
        return self._id

    @property
    def dvorana(self):
        return self._dvorana

    @property
    def red(self):
        return self._red

    @property
    def mjestau_redovima(self):
        return mjestau_redovima

    def __str__(self):
        return """
        id: {0}
        dvorana: {1}
        red: {2}
        mjestau_redovima: {3}
        ----------------
        """.format(self._id, self._dvorana, self._red, self._mjestau_redovima)


class Film():

    def __init__(self, id, naziv, zanr, trajanje):
        self._id = id
        self._naziv = naziv
        self._zanr = zanr
        self._trajanje = trajanje

    @property
    def id(self):
        return self._id

    @property
    def naziv(self):
        return self._naziv

    @property
    def zanr(self):
        return self._zanr

    @property
    def trajanje(self):
        return trajanje

    def __str__(self):
        return """
        id: {0}
        naziv: {1}
        zanr: {2}
        trajanje: {3}
        ----------------
        """.format(self._id, self._naziv, self._zanr, self._trajanje)


class Kupac():

    def __init__(self, id, korisnickoIme, email):
        self._id = id
        self._korisnicnoIme = korisnickoIme
        self._email = email

    @property
    def id(self):
        return self._id

    @property
    def korisnickoIme(self):
        return self._korisnickoIme

    @property
    def email(self):
        return self._email

    def __str__(self):
        return """
        id: {0}
        korisnickoIme: {1}
        email: {2}
        ----------------
        """.format(self._id, self._korisnickoIme, self._email)


class Zanr():

    def __init__(self, id, naziv):
        self._id = id
        self._naziv = naziv
        
    @property
    def id(self):
        return self._id

    @property
    def naziv(self):
        return self._naziv

    def __str__(self):
        return """
        id: {0}
        naziv: {1}
        ----------------
        """.format(self._id, self._naziv)


class Grickalice():

    def __init__(self, id, naziv):
        self._id = id
        self._naziv = naziv

    @property
    def id(self):
        return self._id

    @property
    def naziv(self):
        return self._naziv

    def __str__(self):
        return """
        id: {0}
        naziv: {1}
        ----------------
        """.format(self._id, self._naziv)

    


    


    
