from bottle import Bottle, run, \
     template, debug, get, route, static_file

import os, sys

from baza import unesi_demo_podatke, procitaj_sve_podatke, sacuvaj_novo_kino, dohvati_kino_po_id, azuriraj_kino, izbrisi_kino

#poziv funkcije koja napuni bazu testnim podacima
unesi_demo_podatke()

#citanje svih podataka iz baze
procitaj_sve_podatke()

dirname = os.path.dirname(sys.argv[0])
template_path = dirname + '\\views'
app = Bottle()
debug(True)

@app.route('/static/<filename:re:.*\.css>')
def send_css(filename):
    return static_file(filename, root=dirname+'/static/assets/css')

@app.route('/static/<filename:re:.*\.css.map>')
def send_cssmap(filename):
    return static_file(filename, root=dirname+'/static/assets/css')

@app.route('/static/<filename:re:.*\.js>')
def send_js(filename):
    return static_file(filename, root=dirname+'/static/assets/js')

@app.route('/static/<filename:re:.*\.js.map>')
def send_jsmap(filename):
    return static_file(filename, root=dirname+'/static/assets/js')



@app.route('/')
def index():
    data = {"developer_name": "PMF student",
            "developer_organization": "PMF"}
    return template('index', data = data)

@app.route('/crud-primjer-novi-prof')
def crud_primjer_novo_kino():
    #vrati template s formom za unos novog profesora
    return template('forma', data=None, form_akcija="/crud-primjer-novo-kino-save", template_lookup=[template_path])

@app.route('/crud-primjer-novo-kino-save', method='POST')
def crud_primjer_novo_kino_save():
    postdata = request.body.read()

    #dohvaćamo podatke po atributu "name" definiranog u input elementu forme
    dvorana = request.forms.get("titula")
    red = int(request.forms.get("red"))
    mjestau_redovima = int(request.forms.get("mjesta u redovima"))

    #sacuvaj profesora u bazu
    sacuvaj_novo_kino(dvorana, red, mjestau_redovima)

    #redirektaj korisnika na pocetnu stranicu
    redirect('/crud-primjer')

@app.route('/crud-primjer-azuriraj-prof')
def crud_primjer_azuriraj_kino():
    #dohvati id od profesora iz query parametara
    kino_id = request.query['kinoid']

    #dohvati sve podatke profesora iz baze podataka
    kino = dohvati_kino_po_id(kino_id)

    #vrati template s formom za unos novog profesora
    return template('forma', data=kino, form_akcija="/crud-primjer-azuriraj-kino-save", template_lookup=[template_path])

@app.route('/crud-primjer-azuriraj-kino-save', method='POST')
def crud_primjer_azuriraj_kino_save():

     #dohvaćamo podatke po atributu "name" definiranog u input elementu forme
    kino_id = request.forms.get("kinoid")
    dvorana = request.forms.get("dvorana")
    red = int(request.forms.get("red"))
    mjestau_redovima = int(request.forms.get("mjesta u redovima"))

    #azuriraj profesora u bazi s novim vrijednostima
    azuriraj_kino(kino_id, dvorana, red, mjestau_redovima)

    #redirektaj korisnika na pocetnu stranicu
    redirect('/crud-primjer')

@app.route('/crud-primjer-izbrisi-prof')
def crud_primjer_izbrisi_kino():

    #dohvati id od profesora iz query parametara
    kino_id = request.query['kinoid']

    #izbrisi profesora iz baze
    izbrisi_kino(kino_id)

    #redirektaj korisnika na pocetnu stranicu
    redirect('/crud-primjer')

@app.route('/')
def index():
    data = {"developer_name": "PMF student",
            "developer_organization": "PMF"}
    return template('index', data = data, template_lookup=[template_path])

run(app, host='localhost', port = 8080)

