import sqlite3
import os, sys

dirname = os.path.dirname(sys.argv[0])
sys.path.append(dirname.replace('\\', '/') + '/entiteti/')

from kino import Kino

def unesi_demo_podatke():
    conn=sqlite3.connect("upi_projekt.db")
    try:
        cur = conn.cursor()
        cur.executescript("""

        DROP TABLE IF EXISTS kino;

        CREATE TABLE kino (
        id INTEGER PRIMARY KEY,
        dvorana text NOT NULL,
        red integer NOT NULL,
        mjestau_redovima integer NOT NULL);
        """)

        print("uspjesno kreirana tablica kina!")

        cur.execute("INSERT INTO kino (dvorana, red, mjestau_redovima) VALUES (?, ?, ?)", ("A", 8, 10))
        cur.execute("INSERT INTO kino (dvorana, red, mjestau_redovima) VALUES (?, ?, ?)", ("B", 5, 6))
        cur.execute("INSERT INTO kino (dvorana, red, mjestau_redovima) VALUES (?, ?, ?)", ("C", 12, 20))
        cur.execute("INSERT INTO kino (dvorana, red, mjestau_redovima) VALUES (?, ?, ?)", ("D", 23, 12))
        cur.execute("INSERT INTO kino (dvorana, red, mjestau_redovima) VALUES (?, ?, ?)", ("E", 20, 10))
        cur.execute("INSERT INTO kino (dvorana, red, mjestau_redovima) VALUES (?, ?, ?)", ("F", 7, 4))
        cur.execute("INSERT INTO kino (dvorana, red, mjestau_redovima) VALUES (?, ?, ?)", ("G", 13, 14))
        cur.execute("INSERT INTO kino (dvorana, red, mjestau_redovima) VALUES (?, ?, ?)", ("H", 7, 8))
        cur.execute("INSERT INTO kino (dvorana, red, mjestau_redovima) VALUES (?, ?, ?)", ("I", 2, 8))
        cur.execute("INSERT INTO kino (dvorana, red, mjestau_redovima) VALUES (?, ?, ?)", ("J", 30, 22))
        conn.commit()

        print("uspjesno uneseni testni podaci u tablicu kina!")

    except Exception as e: 
        print("Dogodila se greska pri kreiranju demo podataka: ", e)
        conn.rollback()

    conn.close()

def procitaj_sve_podatke():
    conn = sqlite3.connect("upi_projekt.db")
    lista_kina = []
    try:

        cur = conn.cursor()
        cur.execute(""" SELECT id, dvorana, red, mjestau_redovima FROM kino """)

        podaci = cur.fetchall()
        
        for _kino in podaci:
            # 0 - id
            # 1 - dvorana
            # 2 - red
            # 3 - mjestau_redovima

            k = Kino(_kino[0], _kino[1], _kino[2], _kino[3])
            lista_kina.append(k)

        print("uspjesno dohvaceni svi podaci iz tablice kina!")

        for k in lista_kina:
            print(k)
    except Exception as e: 
        print("Dogodila se greska pri dohvacanju svih podataka iz tablice kina: ", e)
        conn.rollback()

    conn.close()
    return lista_kina

def sacuvaj_novo_kino(dvorana, red, mjestauredovima):
    conn = sqlite3.connect("upi_projekt_kino.db")
    try:

        cur = conn.cursor()
        cur.execute("INSERT INTO kino (dvorana, red, mjestau_redovima) VALUES (?, ?, ?)", (dvorana, red, mjestauredovima))
        conn.commit()

        print("uspjesno dodano novo kino u bazu podataka")

    except Exception as e: 
        print("Dogodila se greska pri dodavanju novog kina u bazu podataka: ", e)
        conn.rollback()

    conn.close()

def izbrisi_kino(kino_id):
    conn = sqlite3.connect("upi_projekt.db")
    try:

        cur = conn.cursor()
        cur.execute("DELETE FROM kino WHERE id=?;", (kino_id))
        conn.commit()

        print("uspjesno izbrisano kino iz baze podataka")

    except Exception as e: 
        print("Dogodila se greska pri brisanje kina iz baze podataka: ", e)
        conn.rollback()

    conn.close()

def dohvati_kino_po_id(kino_id):
    conn = sqlite3.connect("upi_projekt.db")
    kino = None
    try:

        cur = conn.cursor()
        cur.execute(" SELECT id, dvorana, red, mjestau_redovima FROM kino WHERE id = ?", (kino_id))
        podaci = cur.fetchone()

        print("podaci", podaci)
        kino = Kino(podaci[0], podaci[1], podaci[2], podaci[3])

        print("uspjesno dohvaceno kino iz baze podataka po ID-u")

    except Exception as e: 
        print("Dogodila se greska pri dohvacanju kina iz baze podataka po ID-u: ", e)
        conn.rollback()

    conn.close()
    return kino


def azuriraj_kino(kino_id, dvorana, red, mjestauredovima):
    conn = sqlite3.connect("upi_projekt.db")
    try:

        cur = conn.cursor()
        cur.execute("UPDATE kino SET dvorana = ?, red = ?, mjestau_redovima = ? WHERE id = ?", (dvorana, red, mjestau_redovima, kino_id))
        conn.commit()

        print("uspjesno ažurirano kino iz baze podataka")

    except Exception as e: 
        print("Dogodila se greska pri ažuriranju kina iz baze podataka: ", e)
        conn.rollback()

    conn.close()
    
