class Kino():

    def __init__(self, id, dvorana, red, mjestau_redovima):
        self._id = id
        self._dvorana = dvorana
        self._red = red
        self._mjestau_redovima = mjestau_redovima

    @property
    def id(self):
        return self._id
    @property
    def dvorana(self):
        return self._dvorana


    @property
    def red(self):
        return self._red

    @property
    def mjestau_redovima(self):
        return self._mjestau_redovima

    def __str__(self):
        return """
        id: {0}
        dvorana: {1}
        red: {2}
        mjestau_redovima: {3}
        ----------------
        """.format(self._id, self._dvorana, self._red, self._mjestau_redovima)

    
